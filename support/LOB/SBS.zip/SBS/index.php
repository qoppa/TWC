<?php include($_SERVER['DOCUMENT_ROOT']. '/TWC/core/includes/header.php'); ?>

        <a class="subHead left" href="">Back to Support TV</a>
		
        <div class="right">
        	<?php include($_SERVER['DOCUMENT_ROOT']. '/TWC/core/includes/share.php'); ?>
        </div>
		<div class="clear"></div>
        
		<div class="twc-box-column">
    		
    		<div class="100 section columnControl">
    			<div class="parsys_column twc-col1_100">
    				<div class="parsys parsys0 twc-col1_100-c0 parsys_column">
    					<div class="parbase section">
    						
							<div class="25-75 section columnControl">
								<div class="parsys_column twc-col2_2575">
								
								    <!-- Left Side Rail -->
									<div class="parsys parsys0 twc-col2_2575-c0 parsys_column">
										<div class="parbase section">
											
											<div class="expandable">
                                			    <ul>
                                			        <li><h6>Find Channels</h6></li>
                                			        <li><h6>Advanced Search</h6>
                                			            <ul>
                                			                <li><a href="">Access Advanced Search</a></li>
                                			                <li><a href="">Find Movies</a></li>
                                			                <li><a href="">Find TV Shows</a></li>
                                			                <li><a href="">Favorite Searches</a></li>
                                			                <li><a href="">Find Sports</a></li>
                                			                <li><a href="">Advanced Search Keyboard</a></li>
                                			                <li class="active"><a href="">Search Genres</a></li>
                                			                <li><a href="">Popular Searches</a></li>
                                			            </ul>
                                			        </li>
                                			        <li><h6>Find Alternate Airtimes</h6></li>
                                			        <li><h6>Settings</h6></li>
                                			        <li><h6>Audio Settings</h6></li>
                                			        <li><h6>Enhanced TV</h6></li>
                                			        <li><h6>Favorite Channels</h6></li>
                                			        <li><h6>OnDemand</h6>
                                			            <ul>
                                			                <li><a href="">Lorem</a></li>
                                			                <li><a href="">Ipsum</a></li>
                                			                <li><a href="">Dolor</a></li>
                                			                <li><a href="">Amet</a></li>
                                			                <li><a href="">Flipsum</a></li>
                                			            </ul>
                                			        </li>
                                			        <li><h6>CallerID on TV</h6></li>
                                			        <li><h6>Parental Control</h6></li>
                                			    </ul>
                                			</div>
											
										</div>
										<div class="new section"></div>
									</div>
									<!-- .Left Side Rail -->
									
									<!-- Right Side Content -->
									<div class="parsys parsys1 twc-col2_2575-c1 parsys_column">
										<div class="parbase section">
											
											<div class="sbs-content">
                                                <div class="100 section columnControl">
                                                    <div class="parsys_column twc-col1_100">
                                                        <div class="parsys parsys0 twc-col1_100-c0 parsys_column">
                                                            <div class="parbase section">
                                                    
                                                                <div class="75-25 section columnControl">
                                                                    <div class="parsys_column twc-col2_7525">
                                                                        <div class="parsys parsys0 twc-col2_7525-c0 parsys_column">
                                                                            <div class="parbase section">
                                                                                
                                                                                <h5 class="left">Search Genres</h5>
                                                                                
                                                                            </div>
                                                                            <div class="new section"></div>
                                                                        </div>
                                                                        <div class="parsys parsys1 twc-col2_7525-c1 parsys_column">
                                                                            <div class="parbase section">
                                                                                
                                                                                <div class="cta blue twc-icon-after icon-angle-down right mobile-full">
                                                                                    <a href="#" analyticsname="test">
                                                                                        <span>Need More Help?</span>
                                                                                    </a>
                                                                                </div>
                                                                                
                                                                            </div>
                                                                            <div class="new section"></div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="columnClear"></div>
                                                                </div>
                                                                
                                                            </div>
                                                        <div class="new section"></div>
                                                        </div>
                                                    </div>
                                                    <div class="columnClear"></div>
                                                </div>
                                                
                                                <hr>
                                                
                                                <div class="cta twc-icon-after icon-camera blue-icon right hide-all">
                                               		<a href="#" analyticsname="test">
                                                   		<span>Show All</span>
                                               		</a>
                                                </div>
                                                
                                                <div class="steps">
                                                    <ul>
                                                        <li>
                                                            
                                                            <div class="55-45 section columnControl">
                                                                <div class="parsys_column twc-col2_5545">
                                                                    <div class="parsys parsys0 twc-col2_5545-c0 parsys_column">
                                                                        <div class="parbase section">
                                                                            
                                                                            <span class="arialBold">Step 1</span>
                                                                            <span>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque, dolor, magni perspiciatis molestias nam similique obcaecati rerum dicta distinctio non ipsa at modi natus aliquid repellat.</span>
                                                                            
                                                                        </div>
                                                                        <div class="new section"></div>
                                                                    </div>
                                                                    <div class="parsys parsys1 twc-col2_5545-c1 parsys_column">
                                                                        <div class="parbase section">
                                                                            
                                                                            <figure>
                                                                                <img src="http://placehold.it/264x149" alt="">
                                                                            </figure>
                                                                            
                                                                        </div>
                                                                        <div class="new section"></div>
                                                                    </div>
                                                                </div>
                                                                <div class="columnClear"></div>
                                                            </div>
                                                            
                                                        </li>
                                                        <li>
                                                            
                                                            <div class="55-45 section columnControl">
                                                                <div class="parsys_column twc-col2_5545">
                                                                    <div class="parsys parsys0 twc-col2_5545-c0 parsys_column">
                                                                        <div class="parbase section">
                                                                            
                                                                            <span class="arialBold">Step 2</span>
                                                                            <span>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque, dolor, magni perspiciatis molestias nam similique obcaecati rerum dicta distinctio non ipsa at modi natus aliquid repellat.</span>
                                                                            
                                                                        </div>
                                                                        <div class="new section"></div>
                                                                    </div>
                                                                    <div class="parsys parsys1 twc-col2_5545-c1 parsys_column">
                                                                        <div class="parbase section">
                                                                            
                                                                            <figure>
                                                                                <img src="http://placehold.it/264x264" alt="">
                                                                            </figure>
                                                                            
                                                                        </div>
                                                                        <div class="new section"></div>
                                                                    </div>
                                                                </div>
                                                                <div class="columnClear"></div>
                                                            </div>
                                                            
                                                        </li>
                                                        <li>
                                                            
                                                            <div class="55-45 section columnControl">
                                                                <div class="parsys_column twc-col2_5545">
                                                                    <div class="parsys parsys0 twc-col2_5545-c0 parsys_column">
                                                                        <div class="parbase section">
                                                                            
                                                                            <span class="arialBold">Step 3</span>
                                                                            <span>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque, dolor, magni perspiciatis molestias nam similique obcaecati rerum dicta distinctio non ipsa at modi natus aliquid repellat.</span>
                                                                            
                                                                        </div>
                                                                        <div class="new section"></div>
                                                                    </div>
                                                                    <div class="parsys parsys1 twc-col2_5545-c1 parsys_column">
                                                                        <div class="parbase section">
                                                                            
                                                                            <figure>
                                                                                <img src="http://placehold.it/264x130" alt="">
                                                                            </figure>
                                                                            
                                                                        </div>
                                                                        <div class="new section"></div>
                                                                    </div>
                                                                </div>
                                                                <div class="columnClear"></div>
                                                            </div>
                                                            
                                                        </li>
                                                        <li>
                                                            
                                                            <div class="55-45 section columnControl">
                                                                <div class="parsys_column twc-col2_5545">
                                                                    <div class="parsys parsys0 twc-col2_5545-c0 parsys_column">
                                                                        <div class="parbase section">
                                                                            
                                                                            <span class="arialBold">Step 4</span>
                                                                            <span>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque, dolor, magni perspiciatis molestias nam similique obcaecati rerum dicta distinctio non ipsa at modi natus aliquid repellat.</span>
                                                                            
                                                                        </div>
                                                                        <div class="new section"></div>
                                                                    </div>
                                                                    <div class="parsys parsys1 twc-col2_5545-c1 parsys_column">
                                                                        <div class="parbase section">
                                                                            
                                                                            <figure>
                                                                                <img src="http://placehold.it/264x130" alt="">
                                                                            </figure>
                                                                            
                                                                        </div>
                                                                        <div class="new section"></div>
                                                                    </div>
                                                                </div>
                                                                <div class="columnClear"></div>
                                                            </div>
                                                            
                                                        </li>
                                                        <li>
                                                            
                                                            <div class="55-45 section columnControl">
                                                                <div class="parsys_column twc-col2_5545">
                                                                    <div class="parsys parsys0 twc-col2_5545-c0 parsys_column">
                                                                        <div class="parbase section">
                                                                            
                                                                            <span class="arialBold">Step 5</span>
                                                                            <span>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque, dolor, magni perspiciatis molestias nam similique obcaecati rerum dicta distinctio non ipsa at modi natus aliquid repellat.</span>
                                                                            
                                                                        </div>
                                                                        <div class="new section"></div>
                                                                    </div>
                                                                    <div class="parsys parsys1 twc-col2_5545-c1 parsys_column">
                                                                        <div class="parbase section">
                                                                            
                                                                            <figure>
                                                                                <img src="http://placehold.it/149x264" alt="">
                                                                            </figure>
                                                                            
                                                                        </div>
                                                                        <div class="new section"></div>
                                                                    </div>
                                                                </div>
                                                                <div class="columnClear"></div>
                                                            </div>
                                                            
                                                        </li>
                                                    </ul>
                                               	</div>
											</div>
                                            
										</div>
										<div class="new section"></div>
									</div>
									<!-- .Right Side Content -->
									
								</div>
								<div class="columnClear"></div>
							</div>
    										
    					</div>
    				<div class="new section"></div>
    				</div>
    			</div>
    			<div class="columnClear"></div>
    		</div>
    		
		</div>
				
<?php include($_SERVER['DOCUMENT_ROOT']. '/TWC/core/includes/footer.php'); ?>
